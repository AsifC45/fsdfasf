# chess-favourites-assignment
Chess Favourites Assignment for Intro to Web Development
